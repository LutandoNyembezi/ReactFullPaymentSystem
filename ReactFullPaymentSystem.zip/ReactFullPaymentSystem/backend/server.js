const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const app = express();
app.use(express.json());
app.use(cors());
app.use(helmet());

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });
app.use(limiter);

mongoose.connect("mongodb://localhost:27017/payments", { useNewUrlParser: true, useUnifiedTopology: true });

const UserSchema = new mongoose.Schema({ email: String, password: String });
const PaymentSchema = new mongoose.Schema({ recipient: String, amount: Number, currency: String, user: String });
const User = mongoose.model("User", UserSchema);
const Payment = mongoose.model("Payment", PaymentSchema);

const SECRET = "mysecret";

app.post("/api/register", async (req, res) => {
  const { email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  await User.create({ email, password: hash });
  res.status(201).send("User registered");
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !(await bcrypt.compare(password, user.password)))
    return res.status(401).send("Invalid credentials");
  const token = jwt.sign({ email }, SECRET, { expiresIn: "1h" });
  res.json({ token });
});

app.post("/api/payment", async (req, res) => {
  const auth = req.headers.authorization?.split(" ")[1];
  try {
    const { email } = jwt.verify(auth, SECRET);
    const { recipient, amount, currency } = req.body;
    await Payment.create({ recipient, amount, currency, user: email });
    res.send("Payment successful");
  } catch (err) {
    res.status(403).send("Unauthorized");
  }
});

app.listen(5000, () => console.log("API running on http://localhost:5000"));

import React, { useState } from "react";
export default function Payment() {
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("USD");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");
    const amountRegex = /^\d+(\.\d{1,2})?$/;
    if (!amountRegex.test(amount)) return alert("Invalid amount format.");
    const res = await fetch("http://localhost:5000/api/payment", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token
      },
      body: JSON.stringify({ recipient, amount, currency })
    });
    if (res.ok) alert("Payment sent!"); else alert("Error making payment");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Make Payment</h2>
      <input placeholder="Recipient" value={recipient} onChange={e => setRecipient(e.target.value)} />
      <input placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
      <select value={currency} onChange={e => setCurrency(e.target.value)}>
        <option value="USD">USD</option>
        <option value="EUR">EUR</option>
        <option value="ZAR">ZAR</option>
      </select>
      <button type="submit">Send Payment</button>
    </form>
  );
}

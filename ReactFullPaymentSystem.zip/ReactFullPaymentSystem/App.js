useEffect(() => {
    fetch('http://localhost:5000/api/ping')
      .then(res => res.json())
      .then(data => console.log(data.message))
      .catch(err => console.error(err));
  }, []);
  